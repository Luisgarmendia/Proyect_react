# **Tarea**

1. [x] Eliminar: 10
2. [x] useEffect: 5
3. [x] useRef: 10
4. [x] useContext: 15
5. [x] styled-components: 10


**Fecha de entrega: Lunes de semana de examen.**
